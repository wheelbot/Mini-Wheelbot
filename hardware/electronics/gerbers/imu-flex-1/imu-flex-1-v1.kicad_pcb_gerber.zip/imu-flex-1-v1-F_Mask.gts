G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.8*
G04 #@! TF.CreationDate,2023-10-16T17:17:13+02:00*
G04 #@! TF.ProjectId,imu-flex-1-v1,696d752d-666c-4657-982d-312d76312e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.8) date 2023-10-16 17:17:13*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,4.400000*%
G04 APERTURE END LIST*
D10*
X190000000Y-116000000D03*
X140000000Y-72000000D03*
M02*
